package karate.infrastructure.utils;

public class ConstantsFeatures {


    public static final String CONSUMPTION_LIMITS = "consumption_limits";
    public static final String LOCKUNLOCKON_LINE = "lock_unlock_online";

}
