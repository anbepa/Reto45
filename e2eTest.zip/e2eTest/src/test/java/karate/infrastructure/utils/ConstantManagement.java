package karate.infrastructure.utils;

public class ConstantManagement {
    public static final String BUILD = "build";
    public static final String PROJECT_NAME = "Management process opening product factoring";
    public static final String JSON = "json";
    public static final String CLASS_PATH_KARATE = "classpath:karate";
    public static final String IGNORE = "~@ignore";
    public static final Boolean TRUE = true;
    public static final Integer ZERO = 0;
    public static final Integer ONE = 1;
}